# `@theme.tools/auth`

> **Better Auth Server-Side RBAC & Tenant Context Derivation** (foundational-utilities · layer: `foundations`)

Server-verified session derivation (rejecting client-supplied tenantId spoofing) and allowlisted SSO redirects.

## Narrow Entry Points

- `@theme.tools/auth/contracts` — Pure TypeScript contracts, schemas, and event descriptors (zero DOM/Worker globals).
- `@theme.tools/auth/core` — Deterministic domain state machines and validation logic.
- `@theme.tools/auth/cloudflare` — Cloudflare Workers / Hono route descriptors and binding requirements (D1, KV).
- `@theme.tools/auth/react` — React 19 surface descriptors (`SessionSecurityGuard`).
- `@theme.tools/auth/elements` — Custom Element registration (`<tt-auth-guard>`).
- `@theme.tools/auth/testing` — Deterministic conformance suite and test fixtures.
