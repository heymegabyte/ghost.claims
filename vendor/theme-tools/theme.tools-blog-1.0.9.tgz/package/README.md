# `@theme.tools/blog`

> **ArticleDocument v1.0.0, Plate Studio & Editorial Capabilities** (core-workspace · layer: `engines`)

Lossless Plate <-> ArticleDocument v1.0.0 serialization, citation/media/data validators, and 20 article fixtures.

The `@theme.tools/blog/site` navbar supports `layout: "contained" | "full"`. The default remains contained for backward compatibility; use `layout: "full"` for edge-to-edge product headers with safe-area-aware responsive padding.

`installImageLightbox()` progressively enhances every `img[data-tt-zoom]` into one accessible gallery with click, Enter/Space, Escape, arrow-key, previous/next, caption, counter, focus restoration, and React-friendly cleanup behavior.

`renderSiteNavFromJson()` accepts portable navigation JSON including `brand`, `brandHref`, `links`, `layout`, and optional `logo: { src, alt, width, height }`. Full-width navigation keeps the surface edge-to-edge while centering its content within `--tt-maxw`.

Set `megaMode: "overlay"` with `mega`, `megaSearch`, `megaLatest`, `megaCta`, and `megaQuick` to render a viewport-safe command-search mega menu. Add `account: { href, label, avatarSrc?, avatarAlt?, initials? }` for the accessible profile/avatar affordance at the far right of every navbar variant.

## Narrow Entry Points

- `@theme.tools/blog/contracts` — Pure TypeScript contracts, schemas, and event descriptors (zero DOM/Worker globals).
- `@theme.tools/blog/core` — Deterministic domain state machines and validation logic.
- `@theme.tools/blog/cloudflare` — Cloudflare Workers / Hono route descriptors and binding requirements (D1, R2, KV).
- `@theme.tools/blog/react` — React 19 surface descriptors (`UniversalArticleReader`).
- `@theme.tools/blog/elements` — Custom Element registration (`<tt-article-reader>`).
- `@theme.tools/blog/testing` — Deterministic conformance suite and test fixtures.
