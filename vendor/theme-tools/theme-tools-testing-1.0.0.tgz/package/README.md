# `@theme.tools/testing`

> **450-Item TDD Discipline & Ecosystem Conformance Kit** (core-workspace · layer: `foundations`)

450 TDD catalog obligations across 15 families, affected test selector (<300s CI budget), and release gate evaluator.

## CI publication integrity

`@theme-tools/testing/ci-publication-integrity` verifies immutable workflow dependencies, minimum permissions,
untrusted-job credential and runner isolation, trusted publication triggers, and matching source/build/attestation/
registry/consumer artifact lineage. It performs no publication and accesses no credentials.

## Release-transition compatibility

`@theme-tools/testing/release-transition-compatibility` verifies executed release-N browser tabs across N+1 deployment
and rollback without promoting asset configuration to mixed-release proof.

`@theme-tools/testing/durable-job-recovery` verifies executed duplicate-delivery, crash recovery, partial-batch,
retry-exhaustion, dead-letter, and authorized-replay receipts without claiming exactly-once transport.

`@theme-tools/testing/migration-restore-rehearsal` verifies staged old/new data compatibility, delayed destructive
cleanup, distinct rollback/restore plans, and tenant-safe isolated restores with measured RTO/RPO and integrity checks.

`@theme-tools/testing/journey-release-gate` binds exact release versions to baseline-derived critical-journey
objectives, useful samples, rollout limits, stop/runbook decisions, and shared-fix regression feedback.
and rollback, including lazy routes, draft preservation, explicit asset/recovery strategy, blank screens, and reload
loops. Source and deployment configuration alone cannot satisfy the receipt.

## Narrow Entry Points

- `@theme.tools/testing/contracts` — Pure TypeScript contracts, schemas, and event descriptors (zero DOM/Worker globals).
- `@theme.tools/testing/core` — Deterministic domain state machines and validation logic.
- `@theme.tools/testing/cloudflare` — Cloudflare Workers / Hono route descriptors and binding requirements (BrowserRendering).
- `@theme.tools/testing/react` — React 19 surface descriptors (`TestingOverviewDashboard`).
- `@theme.tools/testing/elements` — Custom Element registration (`<tt-testing-hud>`).
- `@theme.tools/testing/testing` — Deterministic conformance suite and test fixtures.
- `@theme-tools/testing/capability-evidence` — Portable capability reachability,
  honest Golden Path evidence dispositions, and deterministic pairwise-plus-boundary
  coverage generation. Consumers own their routes, personas, policies, and evidence;
  this entry point supplies only framework-neutral contracts and verification.
- `@theme-tools/testing/network-scenarios` — Versioned, framework-neutral
  success/failure/latency/retry/ordering scenario descriptors.
- `@theme-tools/testing/msw-scenarios` — MSW 2 adapters with deterministic
  ordered responses and observable call history.
- `@theme-tools/testing/lifecycle-model` — Deterministic finite-state exploration,
  invalid-transition enumeration, invariant paths, terminal-state checks, and
  replay expectations. Consumers may also declare actors and per-transition
  authorization policy to enumerate unauthorized actor/action attempts separately
  from invalid domain actions; actor policy remains optional and consumer-owned.
- `@theme-tools/testing/provider-contracts` — Redacted provider error envelopes,
  runtime request/success/error compatibility, served-version checks, derived
  serializable success/failure fixtures and mocks, consumer-schema evaluation,
  real-provider verification, and guarded version transitions.
- `@theme-tools/testing/hermetic-fixtures` — Deterministic execution-coordinate
  identifiers and failure-visible LIFO cleanup for parallel test fixtures.
- `@theme-tools/testing/trace-evidence` — Redacted browser/Worker/storage/workflow/provider
  evidence records, minimal trace carriers, deterministic collection, and
  at-most-once committed-effect assertions. It is not a vendor exporter and is
  not live-instrumentation evidence by itself.
- `@theme-tools/testing/async-lifecycle` — Latest-result-wins coordination that
  treats abort as an optimization rather than a correctness boundary, a
  deterministic adversarial scheduler, and setup/cleanup resource accounting.
- `@theme-tools/testing/hydration-store` — Deterministic server/initial-client
  input comparison, recoverable hydration error recording, and external-store
  snapshot/subscription verification aligned with React's supported contract.
- `@theme-tools/testing/native-form-auth` — Browser-native successful-control,
  form-association, autocomplete, paste, whole-value OTP, description, focus,
  and Enter-submission contract verification.
- `@theme-tools/testing/focus-pointer-access` — Measured focus visibility and
  overlay occlusion, WCAG target-size exceptions, virtualized focus stability,
  and keyboard/single-pointer alternatives to nonessential dragging.
- `@theme-tools/testing/adaptive-accessibility` — Measured 320 CSS px/400% zoom
  reflow, WCAG text-spacing overrides, bounded two-dimensional exceptions, and
  forced-colors visibility for controls, focus, selection, and errors.
- `@theme-tools/testing/locale-direction-resilience` — Stored/display value
  separation, locale and timezone round trips, expanded labels and long names,
  logical layout, and representative bidirectional browser evidence.
- `@theme-tools/testing/draft-conflict-safety` — Compare-and-set saves,
  truthful save states, tenant/user/record-scoped drafts, quota export, and
  navigation/deployment/reload recovery without overwriting newer content.
- `@theme-tools/testing/history-restoration-safety` — Persisted history
  restoration, authority revalidation, sensitive-state clearing, exactly-once
  resource reconnection, honest leave warnings, and normal bfcache eligibility.
- `@theme-tools/testing/field-performance-budget` — Sample-aware field p75
  LCP/INP/CLS cohorts, explicit lab separation, and before/after JS, CPU,
  memory, and network budgets across five telemetry integrations.
- `@theme-tools/testing/media-font-rendering-policy` — Responsive media geometry,
  LCP priority, font-loading stability, dynamic-space reservation, constrained-device
  fallback, and network/layout trace contracts.
- `@theme-tools/testing/runtime-module-boundary` — Transitive browser/server/Worker
  import-graph isolation, deliberate client boundaries, optional SDK containment,
  bundle inspection, and measured heavy-interaction strategy contracts.
- `@theme-tools/testing/public-url-contract` — Executed working, redirected,
  missing, and protected URL outcomes with crawlability, canonical, metadata,
  legacy mapping, indexability, rendered-content, and HTTP-status guarantees.
- `@theme-tools/testing/high-risk-property-contract` — Risk-scoped domain
  invariants, bounded seeded campaigns, deterministic dependencies, reduced
  counterexample replay, permanent regression fixtures, and CI runtime budgets.
- `@theme-tools/testing/targeted-mutation-contract` — Deterministic execution of
  narrow caller-supplied baseline and mutant implementations plus verification of
  changed high-risk scope, representative kills, plausible-survivor resolution,
  reviewed equivalence, report evidence, and budget-aware gate placement without
  an arbitrary portfolio mutation score.
- `@theme-tools/testing/built-worker-artifact` — Revision-bound evidence for
  critical requests executed against the actual production Worker bundle, with
  route and middleware traversal, test-only binding isolation, persistence/reset
  proof, and explicit harness concurrency limits kept separate from unit mocks.
- `@theme-tools/testing/affected-selection-cache` — CI-vendor-neutral validation
  of last-successful-main baselines, downstream dependency selection, global
  token/CSS/export/schema/config inputs, cache identity changes, and conservative
  fallback expansion whenever history or impact mapping cannot be proven.
- `@theme-tools/testing/authorization-session-matrix` — Real-boundary negative
  authorization receipts for anonymous, expired, insufficient-role, wrong-owner,
  wrong-tenant, CSRF, and origin probes, with authoritative state invariance,
  secure cookie evidence, and passing login/callback controls.
- `@theme-tools/testing/tenant-isolation-boundaries` — Discovered-surface
  reconciliation and concurrent same-resource collision receipts across tenant-
  scoped caches, storage, jobs, workflows, exports, logs, search, and edge paths,
  including server-derived authority and environment resource separation.
- `@theme-tools/testing/csp-tag-execution` — Deployed CSP enforcement, nonce/hash
  integrity, reviewed least-privilege executable tags, consent, and real-browser
  allow/block evidence without treating report-only headers as enforcement.
- `@theme-tools/testing/content-boundary-receipt` — Executed hostile/valid content,
  server upload/download, tenant storage, safe response-header, and isolated
  executable-preview evidence over the canonical shared content policy.
- `@theme-tools/testing/constrained-outbound-receipt` — Installed-runtime evidence
  for product-owned URL authority, per-hop resolution and redirect validation,
  resolution-bound transport, timeout/size limits, and prohibited-egress absence.

## Capability evidence adoption

Build a `CapabilityEvidenceManifest` from source-inspected routes, navigation,
guards, flags, API/workflow dependencies, and executed artifacts. Parse it with
`CapabilityEvidenceManifestSchema`, then call
`verifyCapabilityEvidenceManifest()`. A live obligation cannot pass with local or
fixture evidence, and a user-facing capability cannot pass without an authorized
route/navigation affordance.

Use `generatePairwiseCoverage()` for ordered test dimensions and explicitly named
boundary cases. Its report publishes the exact pair denominator, covered pairs,
uncovered pairs, selected cases, and retained boundary identities; it does not
claim a mathematically minimal case set.

Network scenario descriptors remain separate from the MSW adapter so Worker and
schema consumers can import the contracts without interception code. Lifecycle
models remain consumer-owned: shared code explores and reports them but never
defines product policy. When a lifecycle declares `actors`, every transition must
declare at least one `allowedActors` entry drawn from that actor set; the report
then marks authorization coverage and enumerates every denied actor attempt.

The standard catalog includes `transientDisconnectRecovery` for proving that a
consumer retains last-known data during a connection loss and refreshes it after
the next successful response.

Provider contract fixtures accept consumer-owned Zod request and success schemas.
The canonical failure envelope retains retryability and request correlation while
rejecting secret-like detail keys; credentials and product payload policy remain
in the consumer.

Hermetic fixture identifiers include suite, test, project, worker, retry, and run
seed coordinates. Cleanup registries execute every action in reverse registration
order and report redacted failures rather than abandoning later cleanup.

## Deterministic async lifecycle testing

Create one `LatestTaskCoordinator` per mounted consumer scope. Call `begin()` for
each request or entity switch, and route every completion through `commit()`.
The generation and token identity checks prevent an older completion from
overwriting newer state even when an upstream operation ignores its abort signal.
Call `dispose()` during unmount so every later completion is rejected.

Register listeners, subscriptions, timers, requests, and custom effects with a
`LifecycleResourceRegistry`; each registration transfers cleanup ownership to
the registry. Assert `disposeAll()` succeeds and leaves `remaining === 0` after
repeated mount/unmount cycles. Use `DeterministicAsyncScheduler` to resolve old
work after new work rather than relying on wall-clock delays.

The shared harness proves the mechanism, not consumer adoption. A site remains
in progress until its own adversarial old-after-new, unmount-during-work, and
repeated-cleanup checks execute against the real integration surface.

For SSR routes, create snapshots from the exact server and initial-client ID
prefix, generated IDs, theme, locale/timezone, flags, auth state, and initial
data, then require `compareHydrationSnapshots()` to pass before hydration. Wire
`HydrationRecoveryMonitor.capture()` to React's `onRecoverableError`; the monitor
records and redacts recovery but never suppresses it or mutates framework-owned
DOM. Test external stores through `verifyExternalStoreContract()` so repeated
reads return the same reference, `getServerSnapshot()` matches the first client
snapshot, each logical change emits once, and unsubscribe removes the listener.

For forms and authentication, describe the real rendered controls with
`NativeFormAuthContract` and require `verifyNativeFormAuthContract()` to pass.
Use `serializeSuccessfulControls()` to assert the intended `FormData` subset:
disabled and unchecked controls are omitted while read-only named controls are
retained. Credential tests must preserve password-manager autocomplete tokens,
paste, native Enter submission, invalid-control focus, description targets, and
a single real `autocomplete="one-time-code"` input that accepts the whole code.
### Portfolio consumer adoption kits

`@theme-tools/testing/portfolio-adoption-kit` verifies preparation-only installation kits for requirement traceability and instruction provenance. Kits bind an exact consumer revision to target files, canonical source digests, verification commands, and repository-local review blockers; they never count as installed or passing consumer evidence.

`@theme-tools/testing/consumer-evidence-adoption-bundle` renders the complete planned I02 manifest, verifier, and focused test. It optionally renders an `AGENTS.md.review-required.md` companion for I03, but never invents `AGENTS.md`. Its installation planner returns only `create`, `unchanged`, or `conflict`, making dry runs content-addressed, idempotent, and non-destructive.
